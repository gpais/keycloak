export * from './customers.model';
export * from './customers-popup.service';
export * from './customers.service';
export * from './customers-dialog.component';
export * from './customers-delete-dialog.component';
export * from './customers-detail.component';
export * from './customers.component';
export * from './customers.route';
